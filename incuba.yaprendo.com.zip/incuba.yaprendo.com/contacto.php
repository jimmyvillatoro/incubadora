<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>Acerca de</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		<link href="dat/css/style.css" rel="stylesheet" type="text/css" media="all" />
	</head>
	
	<body>

		<div id="wrapper">
		
			<div id="logo">
				<h1>incubo.<span>yaprendo.com</span></h1>
					<p>sistema en línea</p>
			</div>
			
			<div id="page" class="round">
			
			<div id="menu" class="round">
			<ul>
<li><a href="index.html" title="" class="round">Inicio</a></li>
<li><a href="sesion.php" title="" class="round">Acceso</a></li>
<li><a href="contacto.php" title="" class="round active">Acerca de</a></li>
<li><a href="soporte.php" title="" class="round">Soporte</a></li>
			</ul>		
				</div>

				
				<div id="wrapper2" class="round">
				
					<div id="sidebar" class="round">
					
					<h3>Índice</h3>
			<ul>
<li><a href="index.html" title="" class="round active">Inicio</a></li>
<li><a href="sesion.php" title="" class="round">Acceso</a></li>
<li><a href="contacto.php" title="" class="round">Acerca de</a></li>
<li><a href="soporte.php" title="" class="round">Soporte</a></li>
			</ul>				
						
						
       
					
			<!-- End Sidebar -->				
					</div>
		
				<div id="content" class="round">
					
	
					<h3>Incubadora</h3>
						<ul>
    <li>Nuestra incubadora casera tiene 22"x18"x17" de dimensiones hecha de madera, con una capacidad de 60 huevos.</li>
    <li>Cuenta con dispositivos como: Termómetro, Hidrometro, Termostato, Timer de 8 hrs para el dispositivo de volteo de huevos.</li>
		  	<li>La ventilación es controlada por 2 ventiladores de 12volts y la Temperatura es creada por dos focos de 60 whats.</li>
    <li>Las conexiones eléctricas estan juntas en un dispositivos electrónicos multicontacto.</li>
						</ul>

			<h3>Sistema de control</h3>
						<ul>
    <li>La plataforma web con aplicación app para celulares Android tiene la capacidas de registrar su granja y el número de incubadoras que haya adquirido.</li>
    <li>Llevar el registro y control de cada una de sus incubadoras por modelo y capacidad.</li>
		  	<li>Cuenta con registro del itinerario de incubación con sugerencias automaticas para calibración de temperatura y humedad.</li>
    <li>Maneja automaticamente estadisticas de producción, gracias al registro de su información y previene situaciones de errores y recomienda al granjero acciones para la mejor efectividad productiva.</li>
						</ul>

		<h3>Manuales</h3>
						<ul>
    <li><a href="dat/Incubadora.pdf">Manual de incubadora.</a></li>
    <li>Manual de mantenimiento de incubadora.</li>
    <li><a href="dat/Incubadora2.pdf">Manual de capacitación para granjeros</a></li>
	<li>Manual para utilización de sistema en línea</li>
    <li>Manual para la capacitación a distancia.</li>
    <li>Manual de Asesores de Negocios</li>
						</ul>

						<h3>Contactos</h3>
						<ul>
    <li>Ventas</li>
    <li>ventas@yaprendo.com</li>
		  	<li>Soporte</li>
    <li>soporte@yaprendo.com</li>
						</ul>
							<!-- End Content -->
					</div>
			
					<div style="clear: both"></div>
			
				<!-- End Wrapper 2 -->
				</div>
				
			<!-- End Page -->
			</div>
		
		<!-- End Wrapper -->
		</div>	
	
<div id="footer">
			
<p>copyright &copy; 2020 (yaprendo) <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p>
		
</div>
		
		

<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.</div></body>
	

	
</html>
