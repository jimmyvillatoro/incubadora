<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>Sistema Granjas</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		<link href="dat/css/style.css" rel="stylesheet" type="text/css" media="all" />


<?php
include 'dat/cdb/db.php';


$Idusu = utf8_decode($_GET['Idusu']);
$Idemp = utf8_decode($_GET['Idemp']);
$Idinc = utf8_decode($_GET['Idinc']);
$Iditi = utf8_decode($_GET['Iditi']);

$resultado=mysqli_query($db_connection, "SELECT Nombres, Idemp FROM usuarios  WHERE Idusu = '".$Idusu."' ");

while ($row =mysqli_fetch_array($resultado)) {
   	 $Nombres=$row[Nombres];
    $Idempl=$row[Idemp];
   }
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>
	</head>
	
	<body>

		<div id="wrapper">
		
			<div id="logo">
				<h1>Control de<span> Granjas</span></h1>
				<p>Area de configuración y personalizacion de tus granjas</p>
			</div>
			
			<div id="page" class="round">
			
				<div id="menu" class="round">
			<ul>
<li><a href="index.html" title="" class="round">Inicio</a></li>
<li><a href="sesion.php" title="" class="round">Acceso</a></li>
<li><a href="usuarios.php?Idusu=<?php echo $Idusu; ?>&Idemp=<?php echo $Idemp; ?>&Idinc=<?php echo $Idinc; ?>&Iditi=<?php echo $Iditi; ?>" title="" class="round active">Administración</a></li>
<li><a href="contacto.php" title="" class="round">Acerca de</a></li>
<li><a href="soporte.php" title="" class="round">Soporte</a></li>
			</ul>
				</div>

				
				<div id="wrapper2" class="round">
				
					<div id="sidebar" class="round">
					
			<h3>Índice</h3>
			<ul>
<li><a href="index.html" title="" class="round active">Inicio</a></li>
<li><a href="sesion.php" title="" class="round">Acceso</a></li>
<li><a href="contacto.php" title="" class="round">Acerca de</a></li>
<li><a href="soporte.php" title="" class="round">Soporte</a></li>
			</ul>				
				

					<!-- End Sidebar -->				
					</div>
					
					<div id="content" class="round">
					

<p>Usuario:<a style="color:orange;"> <?php echo $Nombres; ?> </a></p>


<div id="wrapper2" class="round">					
<div id="sidebar2" class="round">					
<h3>Lista de Granjas</h3>					
<ul>

<li>
<a href="regemp.php?Idusu=<?php echo $Idusu; ?>&Idemp=<?php echo $Idemp; ?>"> <img src="dat/ima/agregar.jpg" alt="" width="40" height="40"  class="round"/> </a>Agregar Granja</br>
</li>
<?php
include 'dat/cdb/db.php';
$Idemp = utf8_decode($_GET['Idemp']);

if($Idesc<0)
$Idemp=$Idempl;

$resultado1=mysqli_query($db_connection, "SELECT Idemp, Empresa FROM empresas WHERE  Estado=1 && Idemp='".$Idemp."' ORDER BY Idemp  ");

if (mysqli_num_rows($resultado1)>0)
{			  
      while ($row1 =mysqli_fetch_array($resultado1)) 
	  {
   $Idemp2=$row1[Idemp];
	  $Empresa=$row1[Empresa];

?> 
<li><a href="usuarios.php?Idusu=<?php echo $Idusu; ?>&Idemp=<?php echo $Idemp2; ?>"> <img src="dat/ima/select.jpg" alt="" width="40" height="40"  class="round"/> </a> <?php echo $Empresa; ?> <a href="actemp.php?Idusu=<?php echo $Idusu; ?>&Idemp=<?php echo $Idemp; ?>"> <img src="dat/ima/actualiza.png" alt="" width="40" height="40"  class="round"/> </a></li>
<?php
      }
}
mysqli_free_result($resultado1);
mysqli_close($db_connection);
 ?>				
</ul>

			
<h3>Lista de Incubadoras</h3>
<ul>

<li><a href="reginc.php?Idusu=<?php echo $Idusu; ?>&Idemp=<?php echo $Idemp; ?>"> <img src="dat/ima/agregar.jpg" alt="" width="40" height="40"  class="round"/> </a>Agregar Incubadora</li>

<?php
include 'dat/cdb/db.php';
$Idemp = utf8_decode($_GET['Idemp']);

$resultado2=mysqli_query($db_connection, "SELECT Idinc, Modelo FROM incubadoras WHERE  Idemp='".$Idemp."' ORDER BY Idinc ");

if (mysqli_num_rows($resultado2)>0)
{			  
      while ($row2 =mysqli_fetch_array($resultado2)) 
	  {
   $Idinc2=$row2[Idinc];
	  $Modelo=$row2[Modelo];

?> 
<li><a href="usuarios.php?Idusu=<?php echo $Idusu; ?>&Idemp=<?php echo $Idemp; ?>&Idinc=<?php echo $Idinc2; ?>"> <img src="dat/ima/select.jpg" alt="" width="40" height="40"  class="round"/> </a> <?php echo $Modelo; ?> <a href="actinc.php?Idusu=<?php echo $Idusu; ?>&Idemp=<?php echo $Idemp; ?>&Idinc=<?php echo $Idinc2; ?>"> <img src="dat/ima/actualiza.png" alt="" width="40" height="40"  class="round"/> </a></li>
<?php
      }
}
mysqli_free_result($resultado2);
mysqli_close($db_connection);
 ?>				
</ul>


<h3>Lista de Itinerarios</h3>
<ul>

<li><a href="regiti.php?Idusu=<?php echo $Idusu; ?>&Idemp=<?php echo $Idemp; ?>&Idinc=<?php echo $Idinc; ?>"> <img src="dat/ima/agregar.jpg" alt="" width="40" height="40"  class="round"/> </a>Agregar Itinerarios</li>

<?php
include 'dat/cdb/db.php';
$Idinc = utf8_decode($_GET['Idinc']);
$Iditi = utf8_decode($_GET['Iditi']);

$resultado3=mysqli_query($db_connection, "SELECT Iditi, Dia, Fecha, Temperatura, Humedad, Hora, Nota FROM itinerarios WHERE  Idinc='".$Idinc."' ORDER BY Iditi ");

if (mysqli_num_rows($resultado3)>0)
{			  
      while ($row3 =mysqli_fetch_array($resultado3)) 
	  {
   $Iditi2=$row3[Iditi];
	  $dia=$row3[Dia];
   $fec=$row3[Fecha];
   $tem=$row3[Temperatura];
   $hum=$row3[Humedad];
   $hor=$row3[Hora];
   $not=$row3[Nota];

?> 
<li><a href="usuarios.php?Idusu=<?php echo $Idusu; ?>&Idemp=<?php echo $Idemp; ?>&Idinc=<?php echo $Idinc; ?>&Iditi=<?php echo $Iditi2; ?>"> <img src="dat/ima/select.jpg" alt="" width="40" height="40"  class="round"/> </a><?php echo $dia; ?> - <?php echo $fec; ?> - <?php echo $tem; ?>° - <?php echo $hum; ?>% - <?php echo $hor; ?> - <?php echo $not; ?> <a href="actiti.php?Idusu=<?php echo $Idusu; ?>&Idemp=<?php echo $Idemp; ?>&Idinc=<?php echo $Idinc; ?>&Iditi=<?php echo $Iditi2; ?>"> <img src="dat/ima/actualiza.png" alt="" width="40" height="40"  class="round"/> </a></li>
<?php
      }
}
mysqli_free_result($resultado3);
mysqli_close($db_connection);
 ?>				

</ul>


<h3>Resultados de incubación</h3>
<ul>


<?php
include 'dat/cdb/db.php';
$Idinc = utf8_decode($_GET['Idinc']);

$resultado4=mysqli_query($db_connection, "SELECT Resultado, Nota FROM incubadoras WHERE  Idinc='".$Idinc."' ORDER BY Idinc ");

if (mysqli_num_rows($resultado4)>0)
{			  
      while ($row4 =mysqli_fetch_array($resultado4)) 
	  {
   $Res=$row4[Resultado];
	  $Not=$row4[Nota];

?> 
<li><a href="usuarios.php?Idusu=<?php echo $Idusu; ?>&Idemp=<?php echo $Idemp; ?>&Idinc=<?php echo $Idinc; ?>"> <img src="dat/ima/select.jpg" alt="" width="40" height="40"  class="round"/> </a> Resultado: <?php echo $Res; ?> Nota: <?php echo $Not; ?> <a href="actincr.php?Idusu=<?php echo $Idusu; ?>&Idemp=<?php echo $Idemp; ?>&Idinc=<?php echo $Idinc; ?>"> <img src="dat/ima/actualiza.png" alt="" width="40" height="40"  class="round"/> </a></li>
<?php
      }
}
mysqli_free_result($resultado4);
mysqli_close($db_connection);
 ?>				
</ul>


<h3>Registra al Encargado</h3>					
<ul>
<li align="center">
<a href="regusu2.php?Idusu=<?php echo $Idusu; ?>&Idemp=<?php echo $Idemp; ?>"> <img src="dat/ima/users.png" alt="" width="200" height="150"  class="round" /> </a></li>

<li align="center"><a href="regusu2.php?Idusu=<?php echo $Idusu; ?>&Idemp=<?php echo $Idemp; ?>">Agregar encargado</a></li>					
</ul>

<h3>Control de tú perfil</h3>					
<ul>
<li align="center">
<a href="actusu.php?Idusu=<?php echo $Idusu; ?>&Idemp=<?php echo $Idemp; ?>"> <img src="dat/ima/user.jpeg" alt="" width="200" height="150"  class="round" /> </a></li>
<li align="center"><a href="actusu.php?Idusu=<?php echo $Idusu; ?>&Idemp=<?php echo $Idemp; ?>">Actualiza tú perfil</a></li>					
</ul>

<h3>Información</h3>
						
<ul>
<li>Los datos están seguros en la nube, pero puedes tener instalada nuestra plataforma en tu sitio web.</li>
<li align="center">
<img src="dat/ima/datos.jpg" alt="" width="200" height="150" class="round" />     
</li>
<li>Nosotros hicimos está plataforma pensando en un mejor rendimiento para su granja.</li>
						
</ul>

<!-- End Sidebar -->
</div>

    </div>
					
					<!-- End Content -->
					</div>
			
					<div style="clear: both"></div>
			
				<!-- End Wrapper 2 -->
				</div>
				
			<!-- End Page -->
			</div>
		
		<!-- End Wrapper -->
		</div>
		
	<div id="footer">
			
<p>copyright &copy; 2020 yaprendo <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p>
		
</div>

<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.</div>
</body>
	

</html>
