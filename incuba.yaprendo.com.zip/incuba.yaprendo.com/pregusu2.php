<?php

include 'dat/cdb/db.php';

$nom = $_REQUEST['nom'];
$ape = $_REQUEST['ape'];
$mov = $_REQUEST['mov'];
$cor = $_REQUEST['cor'];
$pas = $_REQUEST['pas'];

$Idusu = $_REQUEST['Idusu'];
$Idemp = $_REQUEST['Idemp'];

date_default_timezone_set('America/Mexico_City');
$script_tz = date_default_timezone_get();
$date = date("Y-m-d");
$time = date('H:i:s', time());


$resultado=mysqli_query($db_connection, "SELECT Idusu FROM usuarios WHERE Idusu = '".$Idusu."' ");
 

if (mysqli_num_rows($resultado)>0)
{

$insert_value = "INSERT INTO usuarios (Nombres, Apellidos, Correo, Movil, Pass, Idesc, Estado) VALUES ('".$nom."',  '".$ape."',  '".$cor."',  '".$mov."',  '".$pas."', '".$Idemp."',2)";

$retry_value = mysqli_query($db_connection,$insert_value);

header('Location: usuarios.php?Idusu='.$Idusu.'&Idemp='.$Idemp.'');



 } else {

header('Location: index.php');
}

mysqli_free_result($retry_value);
mysqli_close($db_connection);
?>
