-- phpMyAdmin SQL Dump
-- version 4.1.10
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 12, 2020 at 07:14 AM
-- Server version: 5.1.62
-- PHP Version: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `incubadoras`
--
CREATE DATABASE IF NOT EXISTS `incubadoras` DEFAULT CHARACTER SET latin1 COLLATE latin1_spanish_ci;
USE `incubadoras`;

-- --------------------------------------------------------

--
-- Table structure for table `empresas`
--

DROP TABLE IF EXISTS `empresas`;
CREATE TABLE IF NOT EXISTS `empresas` (
  `Idemp` int(11) NOT NULL AUTO_INCREMENT,
  `Empresa` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `Ubicacion` varchar(150) COLLATE latin1_spanish_ci NOT NULL,
  `Movil` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `Correo` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Logo` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Empresario` varchar(100) COLLATE latin1_spanish_ci NOT NULL,
  `Fecha` date NOT NULL,
  `Estado` int(11) NOT NULL,
  PRIMARY KEY (`Idemp`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=2 ;

--
-- Triggers `empresas`
--
DROP TRIGGER IF EXISTS `Delempresas`;
DELIMITER //
CREATE TRIGGER `Delempresas` BEFORE DELETE ON `empresas`
 FOR EACH ROW delete from incubadoras where Idemp=Idemp
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `incubadoras`
--

DROP TABLE IF EXISTS `incubadoras`;
CREATE TABLE IF NOT EXISTS `incubadoras` (
  `Idinc` int(11) NOT NULL AUTO_INCREMENT,
  `Modelo` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Cantidad` int(11) NOT NULL,
  `Tipo` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Descrip` text COLLATE latin1_spanish_ci NOT NULL,
  `Fecha` date NOT NULL,
  `Hora` time NOT NULL,
  `Estado` int(11) NOT NULL,
  `Idemp` int(11) DEFAULT NULL,
  PRIMARY KEY (`Idinc`),
  KEY `Idemp` (`Idemp`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=2 ;

--
-- Triggers `incubadoras`
--
DROP TRIGGER IF EXISTS `Delincubadora`;
DELIMITER //
CREATE TRIGGER `Delincubadora` BEFORE DELETE ON `incubadoras`
 FOR EACH ROW delete from itinerario  where Idinc=Idinc
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `itinerarios`
--

DROP TABLE IF EXISTS `itinerarios`;
CREATE TABLE IF NOT EXISTS `itinerarios` (
  `Iditi` int(11) NOT NULL AUTO_INCREMENT,
  `Fecha` date NOT NULL,
  `Temperatura` float NOT NULL,
  `Humedad` float NOT NULL,
  `Hora` time NOT NULL,
  `Nota` text COLLATE latin1_spanish_ci NOT NULL,
  `Idinc` int(11) NOT NULL,
  PRIMARY KEY (`Iditi`),
  KEY `Idinc` (`Idinc`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE IF NOT EXISTS `usuarios` (
  `Idusu` int(11) NOT NULL AUTO_INCREMENT,
  `Nombres` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Apellidos` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Movil` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `Correo` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Pass` varchar(10) COLLATE latin1_spanish_ci NOT NULL,
  `Foto` varchar(50) COLLATE latin1_spanish_ci NOT NULL,
  `Fecha` date NOT NULL,
  `Estado` int(11) NOT NULL,
  `Idemp` int(11) NOT NULL,
  PRIMARY KEY (`Idusu`),
  UNIQUE KEY `Idemp_2` (`Idemp`),
  KEY `Idemp` (`Idemp`),
  KEY `Idemp_3` (`Idemp`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci AUTO_INCREMENT=2 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
