<?php

include 'dat/cdb/db.php';
$cor = $_GET['cor'];
$pas = $_GET['pas'];



$resultado=mysqli_query($db_connection, "SELECT Idusu, Estado, Idemp FROM usuarios  WHERE Correo = '".$cor."' && Pass= '".$pas."' ");

$cuenta=0;

while ($row =mysqli_fetch_array($resultado)) {
   	$Idusu=$row[Idusu];
	   $Estado=$row[Estado];
    $Idemp=$row[Idemp];
$cuenta++;
   }

if($cuenta==0)//salida
{
header('Location: index.html');

} else{

session_start(); 
$_SESSION['Idusu']=$Idusu;
     //sistema de administracion


 //sistema de usuarios
	if($Estado==1)
    header('Location: usuarios.php?Idusu='.$Idusu.'&Idemp='.$Idemp.'');

	//sistema de caja
	if($Estado==2)
    header('Location: caja.php?Idusu='.$Idusu.'&Idemp='.$Idemp.'');

  }	
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>
