<?php
include 'dat/cdb/db.php';

$res = $_REQUEST['res'];
$not = $_REQUEST['not'];

$Idemp = $_REQUEST['Idemp'];
$Idusu = $_REQUEST['Idusu'];
$Idinc = $_REQUEST['Idinc'];

date_default_timezone_set('America/Mexico_City');
$script_tz = date_default_timezone_get();
$date = date("Y-m-d");
$time = date('H:i:s', time());


$update_value ="UPDATE incubadoras SET Resultado='".$res."', Nota='".$not."' WHERE Idinc='".$Idinc."' ";

$retry_value = mysqli_query($db_connection,$update_value);


header('Location: usuarios.php?Idusu='.$Idusu.'&Idemp='.$Idemp.'&Idinc='.$Idinc.'');


mysqli_free_result($retry_value);
mysqli_close($db_connection);
?>
