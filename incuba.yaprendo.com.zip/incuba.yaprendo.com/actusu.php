<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>Usuarios</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		<link href="dat/css/style.css" rel="stylesheet" type="text/css" media="all" />


<?php
include 'dat/cdb/db.php';

$Idusu = utf8_decode($_GET['Idusu']);
$Idemp = utf8_decode($_GET['Idemp']);
$Idinc = utf8_decode($_GET['Idinc']);
$Iditi = utf8_decode($_GET['Iditi']);
$resultado=mysqli_query($db_connection, "SELECT Nombres, Apellidos, Correo, Movil, Pass FROM usuarios  WHERE Idusu = '".$Idusu."' ");

while ($row =mysqli_fetch_array($resultado)) {
   	 $Nombres=$row[Nombres];
    $ape=$row[Apellidos];
    $cor=$row[Correo];
    $mov=$row[Movil];
    $pas=$row[Pass];
   }
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>
	</head>
	
	<body>

		<div id="wrapper">
		
			<div id="logo">
				<h1>Area de <span>Registro</span></h1>
				
			</div>
			
			<div id="page" class="round">
			
				<div id="menu" class="round">
			<ul>
<li><a href="index.html" title="" class="round">Inicio</a></li>
<li><a href="sesion.php" title="" class="round">Acceso</a></li>
<li><a href="usuarios.php?Idusu=<?php echo $Idusu; ?>&Idemp=<?php echo $Idemp; ?>&Idinc=<?php echo $Idinc; ?>&Iditi=<?php echo $Iditi; ?>" title="" class="round active">Atrás</a></li>
<li><a href="contacto.php" title="" class="round">Acerca de</a></li>
<li><a href="soporte.php" title="" class="round">Soporte</a></li>
			</ul>
				</div>

				<div id="wrapper2" class="round">
				
					<div id="sidebar" class="round">
					
			<h3>Índice</h3>
			<ul>
<li><a href="index.html" title="" class="round active">Inicio</a></li>
<li><a href="sesion.php" title="" class="round">Acceso</a></li>
<li><a href="contacto.php" title="" class="round">Acerca de</a></li>
<li><a href="soporte.php" title="" class="round">Soporte</a></li>
			</ul>				
						

		<!-- End Sidebar -->				
					</div>			
					
					<div id="content" class="round">
					
<!-- aqui la informacion -->	

<p>Usuario:<a style="color:orange;"> <?php echo $Nombres; ?> </a></p>

	<div id="splash" align="center">
<img src="dat/ima/registro.jpg" alt="" width="200" height="200" class="round" align="center" />
				</div>
	
<h3>Actualizar tú perfil</h3>
						<ul>
<li> 


        <p>
            <form action="pactusu.php" method="POST">
                <p align="justify"> Se parte del Equipo hoy</p>


<input type="hidden" name="Idusu" value="<?php echo utf8_decode($_GET['Idusu']); ?>">

<input type="hidden" name="Idemp" value="<?php echo utf8_decode($_GET['Idemp']); ?>">

                <div>
                    <div>

                        <input type="text" name="nom" class="form-control" placeholder="Nombres" class="form-input" value="<?php echo $Nombres; ?>" required>
                    </div>
                    <div>
                        <input type="text" name="ape" class="form-control" placeholder="Apellidos"  value="<?php echo $ape; ?>"
                            class="form-input" required>
                    </div>
                </div>
<div>
                    <div>
                        <input type="email" name="cor" class="form-control" placeholder="Correo" class="form-input"  value="<?php echo $cor; ?>"
                            required>
                    </div>
                </div>
                <div>
                    <div>
                        <input type="text" name="mov" class="form-control" placeholder="Movil" class="form-input"  value="<?php echo $mov; ?>"
                            required>
                    </div>
                </div>
                  <div>
                    <div>
                        <input type="text" name="pas" class="form-control" placeholder="Contraseña" class="form-input"  value="<?php echo $pas; ?>"
                            required>
                    </div>
                </div>


                <div>
                    <div>
                        <button type="submit">¡Actualizar!</button>
                                   </div>
                </div>
            </form>

<p id="ad">Inicia Sesión</p>
<ul>	
	<li><a href="sesion.php?Idesc=<?php echo $Idesc; ?>" title="" 
class="round">Miembros</a></li>
					</ul>	

					
<!-- termina aqui -->				
					<!-- End Content -->
					</div>
			
					<div style="clear: both"></div>
			
				<!-- End Wrapper 2 -->
				</div>
				
			<!-- End Page -->
			</div>
		
		<!-- End Wrapper -->
		</div>
		
		<div id="footer">
			
<p>copyright &copy; 2020 (yaprendo) <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p>
		
</div>
		

<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">;]</a>.</div></body>
	

	
</html>
