<?php

include 'dat/cdb/db.php';

$fec = $_REQUEST['fec'];
$tem = $_REQUEST['tem'];
$hum = $_REQUEST['hum'];
$hor = $_REQUEST['hor'];
$not = $_REQUEST['not'];
$dia = $_REQUEST['dia'];
  
$Idusu = $_REQUEST['Idusu'];
$Idemp = $_REQUEST['Idemp'];
$Idinc = $_REQUEST['Idinc'];
$Iditi = $_REQUEST['Iditi'];

date_default_timezone_set('America/Mexico_City');
$script_tz = date_default_timezone_get();
$date = date("Y-m-d");
$time = date('H:i:s', time());


$update_value ="UPDATE itinerarios SET Dia='".$dia."', Fecha='".$fec."', Temperatura='".$tem."', Humedad='".$hum."', Hora='".$hor."', Nota='".$not."'  WHERE Iditi='".$Iditi."' ";

$retry_value = mysqli_query($db_connection,$update_value);


header('Location: usuarios.php?Idusu='.$Idusu.'&Idemp='.$Idemp.'&Idinc='.$Idini.'&Iditi='.$Iditi.'');


mysqli_free_result($retry_value);
mysqli_close($db_connection);
?>
