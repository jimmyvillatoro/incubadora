<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title>Acceso</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		<link href="dat/css/style.css" rel="stylesheet" type="text/css" media="all" />
	</head>
	
	<body>

		<div id="wrapper">
		
			<div id="logo">
				<h1>incubo.<span>yaprendo.com</span></h1>
				<p>sistema en línea</p>
			</div>
			
			<div id="page" class="round">
			
				<div id="menu" class="round">
					<ul>
<li><a href="index.html" title="" class="round">Inicio</a></li>
<li><a href="sesion.php" title="" class="round active">Acceso</a></li>
<li><a href="contacto.php" title="" class="round">Acerca de</a></li>

<li><a href="soporte.php" title="" class="round">Soporte</a></li>
					</ul>	
				</div>
				
				<div id="splash">
					<img src="dat/ima/sesion.jpg" alt="" width="960" height="300" class="round" />
				</div>
				
				<div id="wrapper2" class="round">
				
					<div id="sidebar" class="round">
					
					<h3>Índice</h3>
			<ul>
<li><a href="index.html" title="" class="round active">Inicio</a></li>
<li><a href="sesion.php" title="" class="round">Acceso</a></li>
<li><a href="contacto.php" title="" class="round">Acerca de</a></li>
<li><a href="soporte.php" title="" class="round">Soporte</a></li>
			</ul>		
						
					
					<!-- End Sidebar -->				
					</div>
					
					<div id="content" class="round">
					
			<h1>Inicia sesión.</h1>
								   
			          <p>
             <div>
      <form action="psesion.php" method="GET">
             <div>
             <div>
 

<input type="text" name="cor" class="form-control"              placeholder="Correo Electrónico" class="form-input" required>
             </div>
             <div>
             <div>
<input type="password" name="pas" class="form-control" placeholder="Contraseña"                              class="form-input" required>
             </div>
             </div>
             </div>

             <div>
             <div>
<button type="submit" class="btn btn-success">Iniciar Sesión</button>
<p></p>
<p align="justify"> Dudas? soporte@yaprendo.com</p>
             </div>
             </div>
             </form>
         </p>
    </div>

	
					
					<!-- End Content -->
					</div>
			
					<div style="clear: both"></div>
			
				<!-- End Wrapper 2 -->
				</div>
				
			<!-- End Page -->
			</div>
		
		<!-- End Wrapper -->
		</div>
<div id="footer">
			
<p>copyright &copy; 2020 (yaprendo) <a href="http://desarrollawebs.com" title="www.desarrollawebs.com">Sitio web</a>.</p>
		
</div>


<div style="text-align: center; font-size: 0.75em;">Diseño de <a href="http://www.desarrollawebs.com/">:]</a>.</div></body>
	

	
</html>
