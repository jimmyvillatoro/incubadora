<?php

include 'dat/cdb/db.php';

$nom = $_REQUEST['nom'];
$ape = $_REQUEST['ape'];
$mov = $_REQUEST['mov'];
$cor = $_REQUEST['cor'];
$pas = $_REQUEST['pas'];


$Idemp = $_REQUEST['Idemp'];
$Idusu = $_REQUEST['Idusu'];

date_default_timezone_set('America/Mexico_City');
$script_tz = date_default_timezone_get();
$date = date("Y-m-d");
$time = date('H:i:s', time());


$update_value ="UPDATE usuarios SET Nombres='".$nom."', Apellidos='".$ape."', Correo='".$cor."', Movil='".$mov."', Pass='".$pas."' WHERE Idusu='".$Idusu."' ";

$retry_value = mysqli_query($db_connection,$update_value);


header('Location: usuarios.php?Idusu='.$Idusu.'&Idemp='.$Idemp.'');


mysqli_free_result($retry_value);
mysqli_close($db_connection);
?>
